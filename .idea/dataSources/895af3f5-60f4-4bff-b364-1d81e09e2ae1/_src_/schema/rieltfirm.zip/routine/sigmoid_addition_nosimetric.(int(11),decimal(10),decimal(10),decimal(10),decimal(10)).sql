CREATE FUNCTION sigmoid_addition_nosimetric(x INT, a1 DECIMAL, с1 DECIMAL, a2 DECIMAL, с2 DECIMAL)
  RETURNS DECIMAL(3, 2)
  BEGIN
   DECLARE mu decimal(3, 2);
SET mu = 1/(1+EXP(-a1(x-c1)))*(1/(1+EXP(-a2(x-c2))));
RETURN mu;
END;
