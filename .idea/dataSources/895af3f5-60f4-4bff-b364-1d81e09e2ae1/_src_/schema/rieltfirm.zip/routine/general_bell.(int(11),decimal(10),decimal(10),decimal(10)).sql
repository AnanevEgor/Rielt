CREATE FUNCTION general_bell(x INT, a DECIMAL, b DECIMAL, c DECIMAL)
  RETURNS DECIMAL(3, 2)
  BEGIN
 DECLARE mu decimal(3, 2);

set mu = 1/POW(ABS((x-c)/a),2*b);
RETURN mu;
END;
