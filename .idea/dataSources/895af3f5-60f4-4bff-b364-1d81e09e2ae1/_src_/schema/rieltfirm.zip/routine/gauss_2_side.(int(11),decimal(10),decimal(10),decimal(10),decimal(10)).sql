CREATE FUNCTION gauss_2_side(x INT, a1 DECIMAL, c1 DECIMAL, a2 DECIMAL, c2 DECIMAL)
  RETURNS DECIMAL(3, 2)
  BEGIN
  DECLARE mu decimal(3, 2);

    IF c1<=c2 THEN
      CASE 
        WHEN x<c1 THEN 
          BEGIN
            SET mu = EXP(POW(x-c1,2)/(-2*pow(a1,2)));
          END;
        WHEN c1<=x AND x<=c2 THEN 
          BEGIN
           SET mu = 1;
          END;
        WHEN x>c2 THEN 
          BEGIN
           SET mu =  EXP(POW(x-c2,2)/(-2*pow(a2,2)));
          END;
      END CASE;
    END IF;
    IF c1>c2 THEN
      CASE 
        WHEN x<c2 THEN 
          BEGIN
            SET mu = EXP(POW(x-c1,2)/(-2*pow(a1,2)));
          END;
        WHEN c2<=x AND x<=c1 THEN 
          BEGIN
            SET mu = EXP(POW(x-c1,2)/(-2*pow(a1,2)))*EXP(POW(x-c2,2)/(-2*pow(a2,2)));
          END;
        WHEN x>c1 THEN 
          BEGIN
            SET mu =  EXP(POW(x-c2,2)/(-2*pow(a2,2)));
          END;
      END CASE;
  END IF;
  RETURN mu;
END;
