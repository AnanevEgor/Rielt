CREATE FUNCTION gauss_simpl_func(x INT, q DECIMAL, c DECIMAL)
  RETURNS DECIMAL(3, 2)
  BEGIN
  DECLARE mu decimal(3, 2);
  SET mu = EXP(-POW((x - c), 2) / POW(q, 2));
  RETURN mu;
END;
