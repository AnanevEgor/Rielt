CREATE FUNCTION triangle_func(x INT, a DECIMAL, b DECIMAL, c DECIMAL)
  RETURNS DECIMAL(3, 2)
  BEGIN
  DECLARE mu decimal(3, 2);
  IF x < a
    OR x > c THEN
    SET mu = 0;
  END IF;
  IF a <= x
    AND x <= b THEN
    SET mu = (x - a) / (b - a);
  END IF;
  IF b <= x
    AND x <= c THEN
    SET mu = (c - x) / (c - b);
  END IF;
  RETURN mu;
END;
