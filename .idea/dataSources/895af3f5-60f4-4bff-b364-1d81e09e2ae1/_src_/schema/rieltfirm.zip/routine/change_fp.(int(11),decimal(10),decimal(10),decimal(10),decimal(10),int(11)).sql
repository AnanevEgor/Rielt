CREATE FUNCTION change_fp(fp INT, a DECIMAL, b DECIMAL, c DECIMAL, d DECIMAL, x INT)
  RETURNS DECIMAL(3, 2)
  BEGIN
  DECLARE mu decimal(3, 2);
  CASE fp
     WHEN  1 THEN SET mu = triangle_func(x, a, b, c);
     WHEN  2 THEN SET mu = trapec_func(x, a, b, c,d);
     WHEN  3 THEN SET mu = gauss_simpl_func(x, a, b);
     WHEN  4 THEN SET mu = gauss_2_side(x, a, b, c, d);
     WHEN  5 THEN SET mu = general_bell(x, a, b, c);
     WHEN  6 THEN SET mu = sigmoid(x, a, b);
     WHEN  7 THEN SET mu = sigmoid_addition(x, a, b, c, d);
     WHEN  8 THEN SET mu = sigmoid_addition_nosimetric(x, a, b, c, d);
  END CASE;
  RETURN mu;
END;
