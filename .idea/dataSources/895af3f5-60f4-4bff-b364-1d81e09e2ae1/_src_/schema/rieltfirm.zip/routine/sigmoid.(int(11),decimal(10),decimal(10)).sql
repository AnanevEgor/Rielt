CREATE FUNCTION sigmoid(x INT, a DECIMAL, с DECIMAL)
  RETURNS DECIMAL(3, 2)
  BEGIN
   DECLARE mu decimal(3, 2);
SET mu = 1/(1+EXP(-a(x-c)));
RETURN mu;
END;
