CREATE TRIGGER update_term
AFTER UPDATE ON ling_term
FOR EACH ROW
  BEGIN

DECLARE x_cur int;
  DECLARE id_cur int UNSIGNED; -- id объекта
  DECLARE done int DEFAULT 0; -- число для переменной
  DECLARE mu decimal(3,2); -- степень принадлежности
  DELETE 
    FROM belong WHERE id_ling_term= NEW.id;
  
 CASE NEW.id_ling_var
   WHEN 1 THEN -- ЦЕНА
      BEGIN 
        DECLARE cur CURSOR FOR SELECT o.id, o.price FROM object o;-- курсор по параметру
        DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done =1;-- для остановки цикла, при выходе за пределы курсора
        OPEN cur; -- открытие курсора
        FETCH cur INTO id_cur, x_cur; -- выборка первой строки
        WHILE done = 0 DO  -- пока не вышла за пределы
          SET mu = change_fp(NEW.id_func_own,NEW.a,NEW.b,NEW.c,NEW.d, x_cur ); -- по функции рачитывается степ. принадл.
          INSERT INTO belong (id_ling_term, id_object, own) 
                 VALUES ( New.id, id_cur, mu);-- сохраняем терма, обьект,степ.принадл.
          FETCH cur INTO id_cur, x_cur; -- идем к след объекту
        END WHILE;
      END;
   WHEN 2 THEN -- ПЛОЩАДЬ КУХНИ
      BEGIN
        DECLARE cur CURSOR FOR SELECT o.id, o.size_kitchen FROM object o;
        DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done =1;
        OPEN cur;
        FETCH cur INTO id_cur, x_cur;
        WHILE done = 0 DO
          SET mu = change_fp(NEW.id_func_own,NEW.a,NEW.b,NEW.c,NEW.d, x_cur );
          INSERT INTO belong (id_ling_term, id_object, own)
          VALUES ( New.id, id_cur, mu);
          FETCH cur INTO id_cur, x_cur;
        END WHILE;
      END;
   WHEN 3 THEN -- ОБЩАЯ ПЛОЩАДЬ
      BEGIN
        DECLARE cur CURSOR FOR SELECT o.id, o.size_amount FROM object o;
        DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done =1;
        OPEN cur;
        FETCH cur INTO id_cur, x_cur;
        WHILE done = 0 DO
          SET mu = change_fp(NEW.id_func_own,NEW.a,NEW.b,NEW.c,NEW.d, x_cur );
          INSERT INTO belong (id_ling_term, id_object, own)
          VALUES ( New.id, id_cur, mu);
          FETCH cur INTO id_cur, x_cur;
        END WHILE;
      END;
   WHEN 4 THEN -- ЖИЛАЯ ПЛОЩАДЬ
      BEGIN
        DECLARE cur CURSOR FOR SELECT o.id, o.size_life FROM object o;
        DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done =1;
        OPEN cur;
        FETCH cur INTO id_cur, x_cur;
        WHILE done = 0 DO
          SET mu = change_fp(NEW.id_func_own,NEW.a,NEW.b,NEW.c,NEW.d, x_cur );
          INSERT INTO belong (id_ling_term, id_object, own)
          VALUES ( New.id, id_cur, mu);
          FETCH cur INTO id_cur, x_cur;
        END WHILE;
      END;
   WHEN 5 THEN -- РАССТОЯНИЕ ДО ПЛЯЖА
      BEGIN
        DECLARE cur CURSOR FOR SELECT o.id, o.distance_to_beach FROM object o;
        DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done =1;
        OPEN cur;
        FETCH cur INTO id_cur, x_cur;
        WHILE done = 0 DO
          SET mu = change_fp(NEW.id_func_own,NEW.a,NEW.b,NEW.c,NEW.d, x_cur );
          INSERT INTO belong (id_ling_term, id_object, own)
          VALUES ( New.id, id_cur, mu);
          FETCH cur INTO id_cur, x_cur;
        END WHILE;
      END;
   WHEN 6 THEN -- РАССТОЯНИЕ ДО МОРЯ
      BEGIN
        DECLARE cur CURSOR FOR SELECT o.id, o.distance_to_sea FROM object o;
        DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done =1;
        OPEN cur;
        FETCH cur INTO id_cur, x_cur;
        WHILE done = 0 DO
          SET mu = change_fp(NEW.id_func_own,NEW.a,NEW.b,NEW.c,NEW.d, x_cur );
          INSERT INTO belong (id_ling_term, id_object, own)
          VALUES ( New.id, id_cur, mu);
          FETCH cur INTO id_cur, x_cur;
        END WHILE;
      END;
   WHEN 7 THEN -- РАССТОЯНИЕ ДО ШКОЛЫ
      BEGIN
        DECLARE cur CURSOR FOR SELECT o.id, o.distance_school FROM object o;
        DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done =1;
        OPEN cur;
        FETCH cur INTO id_cur, x_cur;
        WHILE done = 0 DO
          SET mu = change_fp(NEW.id_func_own,NEW.a,NEW.b,NEW.c,NEW.d, x_cur );
          INSERT INTO belong (id_ling_term, id_object, own)
          VALUES ( New.id, id_cur, mu);
          FETCH cur INTO id_cur, x_cur;
        END WHILE;
      END;
   WHEN 8 THEN -- РАССТОЯНИЕ ДО МАГАЗИНА
      BEGIN
        DECLARE cur CURSOR FOR SELECT o.id, o.distance_to_shop FROM object o;
        DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done =1;
        OPEN cur;
        FETCH cur INTO id_cur, x_cur;
        WHILE done = 0 DO
          SET mu = change_fp(NEW.id_func_own,NEW.a,NEW.b,NEW.c,NEW.d, x_cur );
          INSERT INTO belong (id_ling_term, id_object, own)
          VALUES ( New.id, id_cur, mu);
          FETCH cur INTO id_cur, x_cur;
        END WHILE;
      END;
   WHEN 9 THEN -- ВЫСОТА НАД УРОВНЕМ МОРЯ
      BEGIN
        DECLARE cur CURSOR FOR SELECT o.id, o.hight_on_sea FROM object o;
        DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done =1;
        OPEN cur;
        FETCH cur INTO id_cur, x_cur;
        WHILE done = 0 DO
          SET mu = change_fp(NEW.id_func_own,NEW.a,NEW.b,NEW.c,NEW.d, x_cur );
          INSERT INTO belong (id_ling_term, id_object, own)
          VALUES ( New.id, id_cur, mu);
          FETCH cur INTO id_cur, x_cur;
        END WHILE;
      END;
   WHEN 10 THEN -- РАССТОЯНИЕ ДО ОСТАНОВКИ
      BEGIN
        DECLARE cur CURSOR FOR SELECT o.id, o.distance_to_bus_stop FROM object o;
        DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done =1;
        OPEN cur;
        FETCH cur INTO id_cur, x_cur;
        WHILE done = 0 DO
          SET mu = change_fp(NEW.id_func_own,NEW.a,NEW.b,NEW.c,NEW.d, x_cur );
          INSERT INTO belong (id_ling_term, id_object, own)
          VALUES ( New.id, id_cur, mu);
          FETCH cur INTO id_cur, x_cur;
        END WHILE;
      END;
   WHEN 11 THEN -- ЭТАЖНОСТЬ ЗДАНИЯ
      BEGIN
        DECLARE cur CURSOR FOR SELECT o.id, o.home_floors FROM object o;
        DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done =1;
        OPEN cur;
        FETCH cur INTO id_cur, x_cur;
        WHILE done = 0 DO
          SET mu = change_fp(NEW.id_func_own,NEW.a,NEW.b,NEW.c,NEW.d, x_cur );
          INSERT INTO belong (id_ling_term, id_object, own)
          VALUES ( New.id, id_cur, mu);
          FETCH cur INTO id_cur, x_cur;
        END WHILE;
      END;
   WHEN 12 THEN -- ЭТАЖ
      BEGIN
        DECLARE cur CURSOR FOR SELECT o.id, o.floor FROM object o;
        DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done =1;
        OPEN cur;
        FETCH cur INTO id_cur, x_cur;
        WHILE done = 0 DO
          SET mu = change_fp(NEW.id_func_own,NEW.a,NEW.b,NEW.c,NEW.d, x_cur );
          INSERT INTO belong (id_ling_term, id_object, own)
          VALUES ( New.id, id_cur, mu);
          FETCH cur INTO id_cur, x_cur;
        END WHILE;
      END;
 END CASE;
END;
