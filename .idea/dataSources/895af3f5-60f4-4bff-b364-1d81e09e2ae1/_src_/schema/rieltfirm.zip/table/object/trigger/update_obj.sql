CREATE TRIGGER update_obj
AFTER UPDATE ON object
FOR EACH ROW
  BEGIN
DECLARE id_term_cur,id_ling_var_cur, id_fun_own_cur int UNSIGNED;
DECLARE a_cur,b_cur,c_cur,d_cur decimal(3,2);
DECLARE done int DEFAULT 0;
DECLARE mu decimal(3,2);
DECLARE cur CURSOR FOR
          SELECT lt.id, lt.id_func_own, lt.id_ling_var, lt.a, lt.b, lt.c, lt.d FROM ling_term lt; 
DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done =1; 
DELETE FROM belong WHERE belong.id_object = NEW.id; -- удаляем все записи с обьектом
OPEN cur; 
FETCH cur INTO id_term_cur, id_fun_own_cur, id_ling_var_cur, a_cur, b_cur, c_cur, d_cur;
WHILE done = 0 DO 
  CASE id_ling_var_cur
    WHEN 1 THEN
      BEGIN
        set mu = change_fp( id_fun_own_cur, a_cur, b_cur, c_cur, d_cur, NEW.price);
        INSERT INTO belong( id_ling_term, id_object, own) VALUES (id_term_cur, NEW.id, mu);
      END;
    WHEN 2 THEN
      BEGIN
        SET mu = change_fp( id_fun_own_cur, a_cur, b_cur, c_cur, d_cur, NEW.size_kitchen);
        INSERT INTO belong( id_ling_term, id_object, own) VALUES (id_term_cur, NEW.id, mu);
      END;
   WHEN 3 THEN
      BEGIN
        SET mu = change_fp( id_fun_own_cur, a_cur, b_cur, c_cur, d_cur, NEW.size_amount);
        INSERT INTO belong( id_ling_term, id_object, own) VALUES (id_term_cur, NEW.id, mu);
      END;
   WHEN 4 THEN
      BEGIN
        SET mu = change_fp( id_fun_own_cur, a_cur, b_cur, c_cur, d_cur, NEW.size_life);
        INSERT INTO belong( id_ling_term, id_object, own) VALUES (id_term_cur, NEW.id, mu);
      END;
   WHEN 5 THEN
      BEGIN
        IF NEW.distance_to_beach THEN
           SET mu = change_fp( id_fun_own_cur, a_cur, b_cur, c_cur, d_cur, NEW.distance_to_beach);
           INSERT INTO belong( id_ling_term, id_object, own) VALUES (id_term_cur, NEW.id, mu);
          END IF;
      END;
   WHEN 6 THEN
      BEGIN
        IF NEW.distance_to_sea THEN
          SET mu = change_fp( id_fun_own_cur, a_cur, b_cur, c_cur, d_cur, NEW.distance_to_sea);
          INSERT INTO belong( id_ling_term, id_object, own) VALUES (id_term_cur, NEW.id, mu);
        END IF;
     END;
   WHEN 7 THEN
      BEGIN
        IF NEW.distance_school then
       
            SET mu = change_fp( id_fun_own_cur, a_cur, b_cur, c_cur, d_cur, NEW.distance_school);
            INSERT INTO belong( id_ling_term, id_object, own) VALUES (id_term_cur, NEW.id, mu);
          END IF;
     END;
   WHEN 8 THEN
      BEGIN
        IF NEW.distance_to_shop then
      
            SET mu = change_fp( id_fun_own_cur, a_cur, b_cur, c_cur, d_cur, NEW.distance_to_shop);
            INSERT INTO belong( id_ling_term, id_object, own) VALUES (id_term_cur, NEW.id, mu);
          END IF;
     END;
   WHEN 9 THEN
      BEGIN
        IF NEW.hight_on_sea then
         
            SET mu = change_fp( id_fun_own_cur, a_cur, b_cur, c_cur, d_cur, NEW.hight_on_sea);
            INSERT INTO belong( id_ling_term, id_object, own) VALUES (id_term_cur, NEW.id, mu);
          END IF;
      END;
   WHEN 10 THEN
      BEGIN
        IF NEW.distance_to_bus_stop then
         
            SET mu = change_fp( id_fun_own_cur, a_cur, b_cur, c_cur, d_cur, NEW.distance_to_bus_stop);
            INSERT INTO belong( id_ling_term, id_object, own) VALUES (id_term_cur, NEW.id, mu);
          END IF;
      END;
   WHEN 11 THEN
      BEGIN
        SET mu = change_fp( id_fun_own_cur, a_cur, b_cur, c_cur, d_cur, NEW.home_floors);
        INSERT INTO belong( id_ling_term, id_object, own) VALUES (id_term_cur, NEW.id, mu);
      END;
   WHEN 12 THEN
      BEGIN
        SET mu = change_fp( id_fun_own_cur, a_cur, b_cur, c_cur, d_cur, NEW.floor);
        INSERT INTO belong( id_ling_term, id_object, own) VALUES (id_term_cur, NEW.id, mu);
      END;
  END CASE;
  FETCH cur INTO id_term_cur, id_fun_own_cur, id_ling_var_cur, a_cur, b_cur, c_cur, d_cur;
END WHILE;
END;
